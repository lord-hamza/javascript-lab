// Task1

const Array = [1, 2, -231, 100, 98210, 99.1, -4];

function sumArray(Array){
    let s = 0;
    for (let ind = 0; ind < Array.length; ind += 1){
        s += Array[ind]
    }
    document.getElementById("task1").innerHTML = s
}
// Task2

function sum(){
    let a = Number(document.getElementById("a").value)
    let b = Number(document.getElementById("b").value)
    let sum = a + b;
    document.getElementById("task2").innerHTML = sum;
    
}

function sub(){
    let a = Number(document.getElementById("a").value)
    let b = Number(document.getElementById("b").value)
    let sub = a - b;
    document.getElementById("task2").innerHTML = sub;

}

function mul(){
    let a = Number(document.getElementById("a").value)
    let b = Number(document.getElementById("b").value)
    let mul = a * b;
    document.getElementById("task2").innerHTML = mul;
    
}

function div(){
    let a = Number(document.getElementById("a").value)
    let b = Number(document.getElementById("b").value)
    let div = a / b;
    document.getElementById("task2").innerHTML = div;

}

// Task3
const sArray = ["e", "d", "c", "b", "a"];
function sort(sArray){
    sortedArr = sArray.sort();
    document.getElementById("sort").innerHTML = sortedArr
}

// Task4

function validate(){
    fname = document.getElementById("fname").value
    lname = document.getElementById("lname").value
    pass = document.getElementById("pass").value

    if (fname == ""){
        document.getElementById("fname").style.borderColor = "red";
        document.getElementById("fname").style.backgroundColor = "salmon";
        alert("Enter your First Name!")
    }
    if (lname == ""){
        document.getElementById("lname").style.borderColor = "red";
        document.getElementById("lname").style.backgroundColor = "salmon";
        alert("Enter your Last Name!")
    }
    if (pass == ""){
        document.getElementById("pass").style.borderColor = "red";
        document.getElementById("pass").style.backgroundColor = "salmon";
        alert("Enter a Password!")
    }
    if (pass.length < 8){
        alert("Password should be more than 8 characters!")
    }
    else{
        alert("Thank you! Information saved")
    }
}

//Task5

//Calculate Tip
function calculateTip() {
    var billAmount = document.getElementById("billamount").value;
    var Quality = document.getElementById("serviceQual").value;
    var totalPeople = document.getElementById("peopleamount").value;
  
    //validate input
    if (billAmount === "" || Quality == 0) {
      alert("Please Enter a Value!");
      return;
    }
    //Check to see if this input is empty or less than or equal to 1
    if (totalPeople === "" || totalPeople <= 1) {
        totalPeople = 1;
      document.getElementById("each").style.display = "none";
    } else {
      document.getElementById("each").style.display = "block";
    }
  
    //Calculate tip
    var totalTip = (billAmount * Quality) / totalPeople;
    document.getElementById("totalTip").style.display = "block";
    document.getElementById("tip").innerHTML = totalTip;
  
  }

  